<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Midia extends Model
{
    //
}
