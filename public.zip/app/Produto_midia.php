<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Produto_midia extends Model
{
    //
}
