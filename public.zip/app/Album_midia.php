<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Album_midia extends Model
{
    //
}
