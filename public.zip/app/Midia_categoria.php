<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Midia_categoria extends Model
{
    //
}
