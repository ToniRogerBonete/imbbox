<?php

namespace App\Http\Controllers;

use App\Produto_midia;
use Illuminate\Http\Request;

class ProdutoMidiaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Produto_midia  $produto_midia
     * @return \Illuminate\Http\Response
     */
    public function show(Produto_midia $produto_midia)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Produto_midia  $produto_midia
     * @return \Illuminate\Http\Response
     */
    public function edit(Produto_midia $produto_midia)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Produto_midia  $produto_midia
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Produto_midia $produto_midia)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Produto_midia  $produto_midia
     * @return \Illuminate\Http\Response
     */
    public function destroy(Produto_midia $produto_midia)
    {
        //
    }
}
