<?php

namespace App\Http\Controllers;

use App\Album_midia;
use Illuminate\Http\Request;

class AlbumMidiaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Album_midia  $album_midia
     * @return \Illuminate\Http\Response
     */
    public function show(Album_midia $album_midia)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Album_midia  $album_midia
     * @return \Illuminate\Http\Response
     */
    public function edit(Album_midia $album_midia)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Album_midia  $album_midia
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Album_midia $album_midia)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Album_midia  $album_midia
     * @return \Illuminate\Http\Response
     */
    public function destroy(Album_midia $album_midia)
    {
        //
    }
}
