<?php

namespace App\Http\Controllers;

use App\Midia_categoria;
use Illuminate\Http\Request;

class MidiaCategoriaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Midia_categoria  $midia_categoria
     * @return \Illuminate\Http\Response
     */
    public function show(Midia_categoria $midia_categoria)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Midia_categoria  $midia_categoria
     * @return \Illuminate\Http\Response
     */
    public function edit(Midia_categoria $midia_categoria)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Midia_categoria  $midia_categoria
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Midia_categoria $midia_categoria)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Midia_categoria  $midia_categoria
     * @return \Illuminate\Http\Response
     */
    public function destroy(Midia_categoria $midia_categoria)
    {
        //
    }
}
