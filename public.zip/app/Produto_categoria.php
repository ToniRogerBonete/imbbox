<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Produto_categoria extends Model
{
    //
}
