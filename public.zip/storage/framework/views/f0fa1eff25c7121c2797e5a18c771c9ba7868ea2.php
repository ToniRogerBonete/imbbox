    <script src="/js/app.js"></script>
    <script src="/js/ekko-lightbox.js"></script>
    <?php echo e($slot); ?>